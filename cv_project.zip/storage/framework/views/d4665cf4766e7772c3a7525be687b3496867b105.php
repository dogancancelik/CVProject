<?php $__env->startSection('content'); ?>
    <br><br>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card">

                        <?php if(session()->has('error')): ?>
                            <div class="alert alert-danger">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                <?php echo e(session()->get('error')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="card-header">Add Employee</div>
                        <div class="card-body">
                            <form enctype="multipart/form-data" id="itemFrom" role="form" method="POST" action="<?php echo e(route('employees.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="type">Name Surname</label>
                                        <input class="form-control" type="text" name="name_surname" value="<?php echo e(old('name_surname', '')); ?>" required>
                                    </div>

                                    <div class="form-group">
                                        <label for="type">CV File</label>
                                        <input class="form-control" type="file" name="file" required>
                                    </div>

                                    <button type="submit" class="btn btn-success float-right">
                                        <i class="fas fa-plus-circle"></i>
                                        <span> Add Employee </span>
                                    </button>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cv_project\resources\views/add.blade.php ENDPATH**/ ?>